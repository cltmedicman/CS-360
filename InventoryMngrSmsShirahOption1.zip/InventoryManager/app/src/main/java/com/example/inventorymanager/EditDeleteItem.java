package com.example.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class EditDeleteItem extends AppCompatActivity {

    Button btn_update,btn_delete, btn_cancel;
    EditText et_name, et_itemquantity;
    TextView tv_itemID;
    FloatingActionButton btn_plus, btn_minus;
    int id;
    ItemModel item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete_item);

        DBInventory dbInventory = new DBInventory(this);
        ArrayList<ItemModel> allItems = dbInventory.getAllItems();

        btn_update =  findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_cancel = findViewById(R.id.btn_cancel);
        et_name = findViewById(R.id.et_name);
        et_itemquantity = findViewById(R.id.et_itemquantity);
        tv_itemID = findViewById(R.id.tv_itemID);
        btn_plus = findViewById(R.id.btn_plus);
        btn_minus = findViewById(R.id.btn_minus);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1);

        for (ItemModel var: allItems) {
            if (var.getId() == id) {
                item = var;
            }
        }

        String name = item.getItemname();
        String qty = String.valueOf(item.getQuantity());
        String id_1 = String.valueOf(item.getId());


        et_name.setText(name);
        et_itemquantity.setText(qty);
        tv_itemID.setText(id_1);

        btn_update.setOnClickListener(view -> {

            ItemModel itemModel;
            String newItem = et_name.getText().toString();
            int newQty = Integer.parseInt(et_itemquantity.getText().toString());
            int newId =  Integer.parseInt(tv_itemID.getText().toString());
            itemModel = new ItemModel(newId, newItem, newQty);
            DBInventory dbInventory1 = new DBInventory(EditDeleteItem.this);
            boolean success = dbInventory1.updateItem(itemModel);

            Toast.makeText(EditDeleteItem.this, "Success = " + success, Toast.LENGTH_SHORT).show();


            Intent intent1 = new Intent(EditDeleteItem.this, HomeActivity.class);
            startActivity(intent1);
        });

        btn_cancel.setOnClickListener(view -> {
            Intent intent12 = new Intent(EditDeleteItem.this, HomeActivity.class);
            startActivity(intent12);
        });

        btn_delete.setOnClickListener(view -> {

            for (ItemModel del: allItems) {
                if (del.getId() == id) {
                    item = del;
                }
            }
            DBInventory dbInventory2 = new DBInventory(EditDeleteItem.this);
            boolean success = dbInventory2.deleteItem(item);

            Toast.makeText(EditDeleteItem.this, "Success = " + success, Toast.LENGTH_SHORT).show();

            Intent intent2 = new Intent(EditDeleteItem.this, HomeActivity.class);
            startActivity(intent2);
        });

        btn_plus.setOnClickListener(view -> {
            int newCount = (Integer.parseInt(et_itemquantity.getText().toString())) + 1;
            String strQty = String.valueOf(newCount);
            et_itemquantity.setText(strQty);
        });

        btn_minus.setOnClickListener(view -> {
            int newCount = (Integer.parseInt(et_itemquantity.getText().toString())) - 1;
            String strQty = String.valueOf(newCount);
            et_itemquantity.setText(strQty);
        });

    }
}