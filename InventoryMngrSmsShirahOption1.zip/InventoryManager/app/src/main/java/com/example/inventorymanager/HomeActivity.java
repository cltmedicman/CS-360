package com.example.inventorymanager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.Date;


public class HomeActivity extends AppCompatActivity {

    Button btn_add;
    EditText et_itemname, et_quantity;
    RecyclerView rv_list;
    RecyclerView.Adapter rvAdapter;
    RecyclerView.LayoutManager rvLayoutManager;
    int i = 0;

    ArrayAdapter itemArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        DBInventory dbInventory = new DBInventory(HomeActivity.this);
        ArrayList<ItemModel> allItems = dbInventory.getAllItems();

        ActivityCompat.requestPermissions(HomeActivity.this, new String[]{Manifest.permission.SEND_SMS}, 100);

        if (ContextCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            for (ItemModel s: allItems) {
                if (s.getQuantity() < 50) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("8005551212",null, "The " + s.getItemname() + " is below the set threshold of 50 in stock", null, null);
                    Toast.makeText(getApplicationContext(), "SMS for low inventory of " + s.getItemname() + "Sent Successfully", Toast.LENGTH_SHORT).show();
                }
            }
        }

        btn_add = findViewById(R.id.btn_add);
        et_itemname = findViewById(R.id.et_itemname);
        et_quantity = findViewById(R.id.et_quantity);
        rv_list = findViewById(R.id.rv_list);

        rv_list.setHasFixedSize(true);
        rvLayoutManager = new LinearLayoutManager(this);
        rv_list.setLayoutManager(rvLayoutManager);
        rvAdapter = new RecycleViewAdapter(allItems, HomeActivity.this);
        rv_list.setAdapter(rvAdapter);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ItemModel itemModel;

                try {
                    itemModel = new ItemModel(-1, et_itemname.getText().toString(), Integer.parseInt(et_quantity.getText().toString()));
                    DBInventory dbInventory = new DBInventory(HomeActivity.this);
                    boolean success = dbInventory.insertItem(itemModel);

                    rvAdapter = new RecycleViewAdapter(dbInventory.getAllItems(), HomeActivity.this);
                    rv_list.setAdapter(rvAdapter);

                    Toast.makeText(HomeActivity.this, "Success = " + success, Toast.LENGTH_SHORT).show();
                }
                catch (Exception e) {
                    Toast.makeText(HomeActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}