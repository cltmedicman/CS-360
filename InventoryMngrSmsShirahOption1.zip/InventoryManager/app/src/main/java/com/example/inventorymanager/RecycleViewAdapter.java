package com.example.inventorymanager;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> {

    List<ItemModel> allItems;
    Context context;

    public RecycleViewAdapter(ArrayList<ItemModel> allItems, Context context) {
        this.allItems = allItems;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(allItems.get(holder.getAdapterPosition()).getItemname());
        holder.quantity.setText(String.valueOf(allItems.get(holder.getAdapterPosition()).getQuantity()));
        int pos = holder.getAdapterPosition();
        holder.parentLayout.setOnClickListener(view -> {
            Intent intent = new Intent(context, EditDeleteItem.class);
            intent.putExtra("id", allItems.get(pos).getId());
            context.startActivity(intent);
        });


    }

    @Override
    public int getItemCount() {
        return allItems.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView quantity;
        ConstraintLayout parentLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            quantity = itemView.findViewById(R.id.quantity);
            parentLayout = itemView.findViewById(R.id.rowLayout);

        }
    }
}
