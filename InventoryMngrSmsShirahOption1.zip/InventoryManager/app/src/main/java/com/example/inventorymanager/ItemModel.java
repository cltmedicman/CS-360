package com.example.inventorymanager;

public class ItemModel {

    private int id;
    private String itemname;
    private int quantity;

    // constructors

    public ItemModel(int id, String itemname, int quantity) {
        this.id = id;
        this.itemname = itemname;
        this.quantity = quantity;
    }

    public ItemModel() {
    }

    // toString

    @Override
    public String toString() {
        return "ItemModel{" +
                "id=" + id +
                ", itemname='" + itemname + '\'' +
                ", quantity=" + quantity +
                '}';
    }

    // getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
