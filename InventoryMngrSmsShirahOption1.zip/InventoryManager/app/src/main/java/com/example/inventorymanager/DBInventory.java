package com.example.inventorymanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBInventory extends SQLiteOpenHelper {

    public static final String DBNAME="inventory.db";

    public DBInventory (Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table items(id INTEGER PRIMARY KEY AUTOINCREMENT, itemname TEXT, quantity INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists items");
    }

    public Boolean insertItem (ItemModel itemModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("itemname", itemModel.getItemname());
        values.put("quantity", itemModel.getQuantity());

        long result = db.insert("items", null, values);
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean updateItem (ItemModel itemModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("itemname", itemModel.getItemname());
        values.put("quantity", itemModel.getQuantity());
        String id = Integer.toString(itemModel.getId());

        long result = db.update("items", values, "id = ?", new String[]{id});
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean deleteItem (ItemModel itemModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("itemname", itemModel.getItemname());
        values.put("quantity", itemModel.getQuantity());
        String id = Integer.toString(itemModel.getId());

        long result = db.delete("items", "id = ?", new String[]{id});
        if(result==-1) return false;
        else
            return true;
    }

    public ArrayList<ItemModel> getAllItems() {
        ArrayList<ItemModel> returnList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from items", null);

        if (cursor.moveToFirst()) {
            do {
                int itemID = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemQuantity = cursor.getInt(2);

                ItemModel newItem = new ItemModel(itemID, itemName, itemQuantity);
                returnList.add(newItem);


            } while (cursor.moveToNext());
        }
        else {

        }

        cursor.close();
        db.close();
        return returnList;
    }

    public Boolean checkitem (String itemname) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from items where itemname=?", new String[] {itemname});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }

    public Boolean checkitemnamequantity(String itemname, Integer quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from items where itemname=? and quantity=?", new String[] {itemname, quantity.toString()});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
}